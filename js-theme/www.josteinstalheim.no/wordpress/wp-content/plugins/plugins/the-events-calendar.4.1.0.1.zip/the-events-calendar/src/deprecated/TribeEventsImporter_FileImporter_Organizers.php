<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Importer__File_Importer_Organizers' );


	class TribeEventsImporter_FileImporter_Organizers extends Tribe__Events__Importer__File_Importer_Organizers {

	}