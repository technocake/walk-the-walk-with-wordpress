<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Embedded_Maps' );


	class TribeEvents_EmbeddedMaps extends Tribe__Events__Embedded_Maps {

	}